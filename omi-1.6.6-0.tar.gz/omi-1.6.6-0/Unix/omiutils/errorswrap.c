/*
**==============================================================================
**
** Copyright (c) Microsoft Corporation. All rights reserved. See file LICENSE
** for license information.
**
**==============================================================================
*/

#define schemaDecl OMI_Errors_schemaDecl
#include "errors.c"
