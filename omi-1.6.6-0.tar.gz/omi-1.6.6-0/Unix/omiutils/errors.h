/*
**==============================================================================
**
** Copyright (c) Microsoft Corporation. All rights reserved. See file LICENSE
** for license information.
**
**==============================================================================
*/

#include "OMI_DebugError.h"

MI_EXTERN_C MI_ClassDecl CIM_Error_rtti;
MI_EXTERN_C MI_ClassDecl OMI_DebugError_rtti;
MI_EXTERN_C MI_ClassDecl OMI_Error_rtti;