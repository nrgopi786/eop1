These interfaces are deprecated (do not use).
