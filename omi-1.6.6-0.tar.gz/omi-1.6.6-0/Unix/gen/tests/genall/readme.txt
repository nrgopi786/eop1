This directory contains a test of the OMI generator (omigen.exe). It 
generates all classes and then attempts to compile them. To run this test,
just type 'make' (or nmake on Windows platforms).

Note: omigen.exe must be on the path to run this test.

