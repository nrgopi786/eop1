/*
**==============================================================================
**
** Copyright (c) Microsoft Corporation. All rights reserved. See file LICENSE
** for license information.
**
**==============================================================================
*/

#include "filtercol.h"


FilterCollection* FilterCollection_New()
{
    return NULL;
}


_Use_decl_annotations_
int FilterCollection_AddFilter(FilterCollection* self, Filter* filter)
{
    return -1;
}
