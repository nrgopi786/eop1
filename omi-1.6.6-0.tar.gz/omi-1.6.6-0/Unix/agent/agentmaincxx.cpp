/*
**==============================================================================
**
** Copyright (c) Microsoft Corporation. All rights reserved. See file LICENSE
** for license information.
**
**==============================================================================
*/

extern "C" int agent_main(int argc, char** argv);

int main(int argc, char** argv)
{
    return agent_main(argc,argv);
}
