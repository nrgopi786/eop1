/*
**==============================================================================
**
** Copyright (c) Microsoft Corporation. All rights reserved. See file LICENSE
** for license information.
**
**==============================================================================
*/

DWORD MakeReports(PCWSTR company, int caseNumber);
DWORD BalanceBooks(PCWSTR company, int caseNumber);

