/*
**==============================================================================
**
** Copyright (c) Microsoft Corporation. All rights reserved. See file LICENSE
** for license information.
**
**==============================================================================
*/

#include <MI.h>
#include "module.h"

MI_BEGIN_NAMESPACE

Module::Module()
{
}

Module::~Module()
{
}

MI_END_NAMESPACE

