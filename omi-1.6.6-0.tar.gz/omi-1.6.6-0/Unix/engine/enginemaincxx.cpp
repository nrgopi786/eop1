/*
**==============================================================================
**
** Copyright (c) Microsoft Corporation. All rights reserved. See file LICENSE
** for license information.
**
**==============================================================================
*/

extern "C" int enginemain(int argc, char** argv);

int main(int argc, char** argv)
{
    return enginemain(argc,argv);
}
