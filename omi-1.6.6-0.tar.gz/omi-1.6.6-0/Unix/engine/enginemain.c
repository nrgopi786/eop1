/*
**==============================================================================
**
** Copyright (c) Microsoft Corporation. All rights reserved. See file LICENSE
** for license information.
**
**==============================================================================
*/

#include <common.h>

int enginemain(int argc, _In_reads_(argc) CharPtr* argv);

int main(int argc, char** argv)
{
    return enginemain(argc,argv);
}
